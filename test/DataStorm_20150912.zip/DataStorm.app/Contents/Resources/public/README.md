DataStorm can help you translate data file from one format to another.

Features:
1. Convert between JSON, XML, CSV, PLIST and YML (YAML) , from one format to another.
2. Convert plist data between PLIST JSON and XML format.
3. Convert cvs data between CSV JSON format.
4. Batch conversion.
5. Multi-language support.

Upgrade:
+ support .properties(java) file.

If you need any feature or have any problem , please mail to us,we will do our best for YOU.
Thanks and Best regards.

